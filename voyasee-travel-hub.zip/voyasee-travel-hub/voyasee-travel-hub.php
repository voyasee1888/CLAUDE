<?php
/**
 * Plugin Name: Voyasee Smart Travel Hub
 * Plugin URI: https://voyasee.com/free-smart-travel-hub/
 * Description: Smart Travel Hub v21.2.0 — Live weather, advisories, currency, AQI, hazards, climate normals and more. Use [voyasee_travel_hub] shortcode to embed anywhere.
 * Version: 21.2.0
 * Author: Voyasee
 * Author URI: https://voyasee.com
 * License: Proprietary
 * Requires at least: 5.6
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function voyasee_travel_hub_shortcode( $atts ) {
    $file = plugin_dir_path( __FILE__ ) . 'travel-hub.html';
    if ( ! file_exists( $file ) ) {
        return '<p style="color:red;font-family:sans-serif;">Voyasee Travel Hub: content file missing. Please re-install the plugin.</p>';
    }
    return file_get_contents( $file );
}
add_shortcode( 'voyasee_travel_hub', 'voyasee_travel_hub_shortcode' );
