<?php
/**
 * Plugin Name: Voyasee Travel Intelligence Bridge
 * Plugin URI: https://voyasee.com/
 * Description: Master destination-intelligence REST layer for Voyasee. Combines the existing Voyasee Weather Bridge and Voyasee Country Intelligence plugins with official advisories, health notices, hazards, airports, nearby essentials, coordinate timezone lookup, source freshness and explainable trip-readiness signals.
 * Version: 1.3.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Voyasee
 * Author URI: https://voyasee.com/
 * License: GPL-2.0-or-later
 * Text Domain: voyasee-travel-intelligence
 */
if (!defined('ABSPATH')) { exit; }

define('VTI_VERSION', '1.3.0');
define('VTI_FILE', __FILE__);
define('VTI_DIR', plugin_dir_path(__FILE__));
define('VTI_URL', plugin_dir_url(__FILE__));
define('VTI_REST_NAMESPACE', 'voyasee-intelligence/v1');

require_once VTI_DIR . 'includes/class-vti-service.php';
require_once VTI_DIR . 'includes/class-vti-rest.php';
require_once VTI_DIR . 'includes/class-vti-admin.php';

final class Voyasee_Travel_Intelligence_Bridge {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action('rest_api_init', array('VTI_REST', 'register_routes'));
        add_action('admin_menu', array('VTI_Admin', 'menu'));
        add_action('admin_init', array('VTI_Admin', 'register_settings'));
        add_action('admin_notices', array($this, 'dependency_notice'));
        add_action('wp_head', array($this, 'print_client_config'), 1);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'action_links'));
        add_filter('rest_post_dispatch', array('VTI_REST', 'add_cache_headers'), 10, 3);
    }

    public function print_client_config() {
        if (is_admin()) { return; }
        $ipapi_key = trim((string) get_option('vti_ipapi_key', ''));
        $config = array(
            'apiBase'  => esc_url_raw(rest_url(VTI_REST_NAMESPACE)),
            'version'  => VTI_VERSION,
            // ipapiKey is set by the site admin in WP Admin → Settings → Voyasee Intelligence.
            // Empty string means the frontend falls back to its own localStorage key or ipapi.co.
            'ipapiKey' => $ipapi_key,
        );
        echo '<script id="voyasee-intelligence-config">window.VoyaseeIntelligenceConfig=window.VoyaseeIntelligenceConfig||' .
            wp_json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . ';</script>' . "\n";
    }

    public function dependency_notice() {
        if (!current_user_can('activate_plugins')) { return; }
        $missing = array();
        if (!class_exists('VWB_Service')) { $missing[] = 'Voyasee Weather Bridge 1.3.0+'; }
        if (!class_exists('VCI_Data')) { $missing[] = 'Voyasee Country Intelligence 2.0.0+'; }
        if (!$missing) { return; }
        echo '<div class="notice notice-warning"><p><strong>Voyasee Travel Intelligence Bridge:</strong> Activate ' .
            esc_html(implode(' and ', $missing)) .
            ' to enable the complete destination report. The master plugin will keep running, but dependent sections will be marked unavailable.</p></div>';
    }

    public function action_links($links) {
        array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=voyasee-intelligence')) . '">Settings</a>');
        return $links;
    }

    public static function activate() {
        $defaults = array(
            'enable_state_department' => 1,
            'enable_govuk' => 1,
            'enable_cdc' => 1,
            'enable_usgs' => 1,
            'enable_gdacs' => 1,
            'enable_eonet' => 1,
            'enable_nws' => 1,
            'enable_overpass' => 1,
            'firms_map_key' => '',
            'meteoalarm_token' => '',
            'ipapi_key' => '',
            'contact_email' => get_option('admin_email'),
            'public_rate_limit' => 45,
        );
        foreach ($defaults as $key => $value) {
            if (false === get_option('vti_' . $key, false)) { update_option('vti_' . $key, $value, false); }
        }
        update_option('vti_activated_at', gmdate('c'), false);
    }
}
register_activation_hook(__FILE__, array('Voyasee_Travel_Intelligence_Bridge', 'activate'));
Voyasee_Travel_Intelligence_Bridge::instance();
