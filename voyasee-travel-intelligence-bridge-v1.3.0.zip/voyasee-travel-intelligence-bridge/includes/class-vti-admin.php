<?php
if (!defined('ABSPATH')) { exit; }
class VTI_Admin {
    public static function menu() {
        add_options_page('Voyasee Intelligence', 'Voyasee Intelligence', 'manage_options', 'voyasee-intelligence', array(__CLASS__, 'page'));
    }

    public static function sanitize_toggle($value) { return empty($value) ? 0 : 1; }
    public static function sanitize_rate($value) { return max(10, min(180, absint($value))); }

    public static function register_settings() {
        $toggles = array('state_department','govuk','cdc','usgs','gdacs','eonet','nws','overpass');
        foreach ($toggles as $field) {
            register_setting('vti_settings', 'vti_enable_' . $field, array(
                'type' => 'integer',
                'default' => 1,
                'sanitize_callback' => array(__CLASS__, 'sanitize_toggle'),
            ));
        }
        register_setting('vti_settings', 'vti_ipapi_key', array('sanitize_callback'=>'sanitize_text_field','default'=>''));
        register_setting('vti_settings', 'vti_firms_map_key', array('sanitize_callback'=>'sanitize_text_field','default'=>''));
        register_setting('vti_settings', 'vti_meteoalarm_token', array('sanitize_callback'=>'sanitize_text_field','default'=>''));
        register_setting('vti_settings', 'vti_contact_email', array('sanitize_callback'=>'sanitize_email','default'=>get_option('admin_email')));
        register_setting('vti_settings', 'vti_public_rate_limit', array('sanitize_callback'=>array(__CLASS__, 'sanitize_rate'),'default'=>45));
    }

    public static function page() {
        if (!current_user_can('manage_options')) { return; }
        $health = VTI_Service::health();
        ?>
        <div class="wrap">
          <h1>Voyasee Travel Intelligence Bridge</h1>
          <p>This master plugin enriches the existing Weather Bridge and Country Intelligence plugins. Keep both active.</p>

          <div class="notice inline <?php echo !empty($health['ready']) ? 'notice-success' : 'notice-warning'; ?>">
            <p><strong>System readiness:</strong> <?php echo !empty($health['ready']) ? 'Ready' : 'Partial'; ?> —
            Weather Bridge: <?php echo !empty($health['dependencies']['weatherBridge']) ? 'active' : 'missing'; ?> ·
            Country Intelligence: <?php echo !empty($health['dependencies']['countryIntelligence']) ? 'active' : 'missing'; ?> ·
            Airport data: <?php echo !empty($health['dependencies']['airportDataset']) ? 'ready' : 'missing'; ?> ·
            Timezone data: <?php echo !empty($health['dependencies']['timezoneGrid']) ? 'ready' : 'missing'; ?></p>
          </div>

          <form method="post" action="options.php">
            <?php settings_fields('vti_settings'); ?>
            <table class="form-table"><tbody>
            <?php foreach (array(
                'state_department'=>'U.S. State Department advisories',
                'govuk'=>'GOV.UK travel advice',
                'cdc'=>'CDC travel health notices',
                'usgs'=>'USGS earthquakes',
                'gdacs'=>'GDACS disasters',
                'eonet'=>'NASA EONET events',
                'nws'=>'NWS alerts for U.S. locations',
                'overpass'=>'OpenStreetMap nearby essentials',
            ) as $key=>$label): ?>
              <tr><th><?php echo esc_html($label);?></th><td>
                <input type="hidden" name="vti_enable_<?php echo esc_attr($key);?>" value="0">
                <label><input type="checkbox" name="vti_enable_<?php echo esc_attr($key);?>" value="1" <?php checked('1',(string)get_option('vti_enable_'.$key,'1'));?>> Enabled</label>
              </td></tr>
            <?php endforeach; ?>
              <tr><th>IPapi.com Key</th><td><input class="regular-text" type="password" autocomplete="off" name="vti_ipapi_key" value="<?php echo esc_attr(get_option('vti_ipapi_key',''));?>"><p class="description">Optional. Used to auto-detect each visitor's country and pre-fill the passport selector in the Travel Hub. Get a free key at <a href="https://ipapi.com/" target="_blank" rel="noopener">ipapi.com</a> (1,000 req/month, no credit card). Leave blank to use ipapi.co keyless fallback (1,000/day free).</p></td></tr>
              <tr><th>NASA FIRMS MAP_KEY</th><td><input class="regular-text" type="password" autocomplete="off" name="vti_firms_map_key" value="<?php echo esc_attr(get_option('vti_firms_map_key',''));?>"><p class="description">Optional free key. Leave blank to disable satellite fire detections.</p></td></tr>
              <tr><th>MeteoAlarm token</th><td><input class="regular-text" type="password" autocomplete="off" name="vti_meteoalarm_token" value="<?php echo esc_attr(get_option('vti_meteoalarm_token',''));?>"><p class="description">Optional re-user token for supported European warning feeds. Without it, Weather Bridge alerts and official verification links still remain available.</p></td></tr>
              <tr><th>Contact email</th><td><input class="regular-text" type="email" name="vti_contact_email" value="<?php echo esc_attr(get_option('vti_contact_email',get_option('admin_email')));?>"><p class="description">Included in the User-Agent sent to public services that request contact details.</p></td></tr>
              <tr><th>Public requests/minute</th><td><input type="number" min="10" max="180" name="vti_public_rate_limit" value="<?php echo esc_attr(get_option('vti_public_rate_limit',45));?>"><p class="description">Per visitor and REST route. Cached responses reduce upstream traffic.</p></td></tr>
            </tbody></table>
            <?php submit_button(); ?>
          </form>
          <p><strong>Health endpoint:</strong> <code><?php echo esc_html(rest_url(VTI_REST_NAMESPACE.'/health'));?></code></p>
          <p><strong>Diagnostics:</strong> <code><?php echo esc_html(rest_url(VTI_REST_NAMESPACE.'/diagnostics'));?></code> — available to logged-in administrators.</p>
        </div>
        <?php
    }
}
