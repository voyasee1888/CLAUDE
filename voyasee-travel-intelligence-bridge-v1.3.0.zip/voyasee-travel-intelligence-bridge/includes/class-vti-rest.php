<?php
if (!defined('ABSPATH')) { exit; }
class VTI_REST {
    public static function register_routes() {
        self::route('/health', 'health', array(), 'health');
        self::route('/report', 'report', self::report_args(), 'report');
        self::route('/timezone', 'timezone', self::latlon_args(), 'timezone');
        self::route('/airports', 'airports', array_merge(self::latlon_args(), array('limit'=>array('default'=>5,'sanitize_callback'=>'absint'))), 'airports');
        self::route('/nearby', 'nearby', array_merge(self::latlon_args(), array('radius'=>array('default'=>5000,'sanitize_callback'=>'absint'))), 'nearby');
        self::route('/hazards', 'hazards', array_merge(self::latlon_args(), array('country'=>array('required'=>false,'sanitize_callback'=>'sanitize_text_field'))), 'hazards');
        self::route('/advisories', 'advisories', array('country'=>array('required'=>true,'sanitize_callback'=>'sanitize_text_field')), 'advisories');
        self::route('/health-notices', 'health_notices', array('country'=>array('required'=>true,'sanitize_callback'=>'sanitize_text_field')), 'health_notices');
        register_rest_route(VTI_REST_NAMESPACE, '/diagnostics', array(
            'methods'=>WP_REST_Server::READABLE,
            'callback'=>array(__CLASS__, 'diagnostics'),
            'permission_callback'=>function(){ return current_user_can('manage_options'); },
        ));
    }
    private static function route($path, $callback, $args, $rate_name) {
        register_rest_route(VTI_REST_NAMESPACE, $path, array(
            'methods'=>WP_REST_Server::READABLE,
            'callback'=>array(__CLASS__, $callback),
            'permission_callback'=>function() use ($rate_name){ return VTI_Service::rate_limit($rate_name); },
            'args'=>$args,
        ));
    }
    private static function latlon_args() {
        return array(
            'lat'=>array('required'=>true,'validate_callback'=>function($v){return is_numeric($v)&&(float)$v>=-90&&(float)$v<=90;}),
            'lon'=>array('required'=>true,'validate_callback'=>function($v){return is_numeric($v)&&(float)$v>=-180&&(float)$v<=180;}),
        );
    }
    private static function report_args() {
        return array_merge(self::latlon_args(), array(
            'country'=>array('required'=>true,'sanitize_callback'=>'sanitize_text_field'),
            'place'=>array('required'=>false,'sanitize_callback'=>'sanitize_text_field'),
            'passport'=>array('required'=>false,'default'=>'OTHER','sanitize_callback'=>'sanitize_text_field'),
            'trip_style'=>array('required'=>false,'default'=>'first','sanitize_callback'=>'sanitize_key'),
            'trip_length'=>array('required'=>false,'default'=>7,'sanitize_callback'=>'absint'),
            'arrival_date'=>array('required'=>false,'sanitize_callback'=>'sanitize_text_field'),
            'arrival_time'=>array('required'=>false,'sanitize_callback'=>'sanitize_text_field'),
            'traveller_type'=>array('required'=>false,'default'=>'solo','sanitize_callback'=>'sanitize_key'),
            'luggage'=>array('required'=>false,'default'=>'carry-on','sanitize_callback'=>'sanitize_key'),
            'aq_sensitive'=>array('required'=>false,'default'=>false,'sanitize_callback'=>'rest_sanitize_boolean'),
            'heat_sensitive'=>array('required'=>false,'default'=>false,'sanitize_callback'=>'rest_sanitize_boolean'),
            'late_arrival'=>array('required'=>false,'default'=>false,'sanitize_callback'=>'rest_sanitize_boolean'),
            'mobility'=>array('required'=>false,'default'=>false,'sanitize_callback'=>'rest_sanitize_boolean'),
            'include_nearby'=>array('required'=>false,'default'=>true,'sanitize_callback'=>'rest_sanitize_boolean'),
        ));
    }
    private static function run($fn) {
        try { $data = call_user_func($fn); }
        catch (Throwable $e) {
            error_log('[Voyasee Travel Intelligence ' . VTI_VERSION . '] ' . $e->getMessage());
            $data = new WP_Error('vti_runtime_error', 'The intelligence service encountered a temporary server error.', array('status'=>500));
        }
        if (is_wp_error($data)) {
            $d=$data->get_error_data();$status=is_array($d)&&isset($d['status'])?(int)$d['status']:400;
            return new WP_REST_Response(array('ok'=>false,'error'=>array('code'=>$data->get_error_code(),'message'=>$data->get_error_message(),'details'=>$d)), $status);
        }
        return rest_ensure_response($data);
    }
    public static function health(){return self::run(function(){return VTI_Service::health();});}
    public static function report(WP_REST_Request $r){return self::run(function()use($r){return VTI_Service::report($r->get_params());});}
    public static function timezone(WP_REST_Request $r){return self::run(function()use($r){return array('ok'=>true,'timezone'=>VTI_Service::timezone((float)$r['lat'],(float)$r['lon']));});}
    public static function airports(WP_REST_Request $r){return self::run(function()use($r){return array('ok'=>true,'airports'=>VTI_Service::nearest_airports((float)$r['lat'],(float)$r['lon'],max(1,min(10,(int)$r['limit']))));});}
    public static function nearby(WP_REST_Request $r){return self::run(function()use($r){return array('ok'=>true,'nearby'=>VTI_Service::nearby((float)$r['lat'],(float)$r['lon'],max(1000,min(15000,(int)$r['radius']))));});}
    public static function hazards(WP_REST_Request $r){return self::run(function()use($r){return array('ok'=>true,'hazards'=>VTI_Service::hazards((float)$r['lat'],(float)$r['lon'],$r['country']));});}
    public static function advisories(WP_REST_Request $r){return self::run(function()use($r){return array('ok'=>true,'advisories'=>VTI_Service::advisories($r['country']));});}
    public static function health_notices(WP_REST_Request $r){return self::run(function()use($r){return array('ok'=>true,'healthNotices'=>VTI_Service::health_notices($r['country']));});}
    public static function diagnostics(){return self::run(function(){return VTI_Service::diagnostics();});}
    public static function add_cache_headers($response,$server,$request){
        if (0!==strpos($request->get_route(),'/'.VTI_REST_NAMESPACE.'/') || !($response instanceof WP_REST_Response)) return $response;
        if ($response->get_status()>=400){$response->header('Cache-Control','no-store');return $response;}
        $ttl=300;if(false!==strpos($request->get_route(),'/report'))$ttl=300;elseif(false!==strpos($request->get_route(),'/health'))$ttl=120;elseif(false!==strpos($request->get_route(),'/airports'))$ttl=86400;
        $response->header('Cache-Control','public, max-age='.$ttl.', stale-while-revalidate='.($ttl*2));
        $response->header('X-Voyasee-Intelligence-Version',VTI_VERSION);
        return $response;
    }
}
