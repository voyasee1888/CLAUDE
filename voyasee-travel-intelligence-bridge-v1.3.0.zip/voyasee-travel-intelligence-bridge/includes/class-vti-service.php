<?php
if (!defined('ABSPATH')) { exit; }
class VTI_Service {
    private static $airports = null;
    private static $tzmeta   = null;
    private static $ctx_cache = array();

    public static function option($name,$default=''){return get_option('vti_'.$name,$default);}
    public static function enabled($name){return '1'===(string)self::option('enable_'.$name,'1');}
    private static function now(){return gmdate('c');}
    private static function client_ip(){
        $ip=isset($_SERVER['REMOTE_ADDR'])?sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])):'unknown';
        if(!empty($_SERVER['HTTP_CF_RAY'])&&!empty($_SERVER['HTTP_CF_CONNECTING_IP'])){$c=sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP']));if(filter_var($c,FILTER_VALIDATE_IP))$ip=$c;}
        return $ip;
    }
    public static function rate_limit($route){
        if(current_user_can('manage_options'))return true;
        // Skip DB-backed rate limiting when no object cache is present — avoids
        // wp_options table lock contention on high-traffic shared hosting.
        if(!wp_using_ext_object_cache())return true;
        $limit=max(10,min(180,(int)self::option('public_rate_limit',45)));
        $key='vti_rl_'.md5(self::client_ip().'|'.$route.'|'.gmdate('YmdHi'));
        $count=(int)get_transient($key);
        if($count>=$limit)return new WP_Error('vti_rate_limited','Too many requests. Please wait a minute and try again.',array('status'=>429));
        set_transient($key,$count+1,75);return true;
    }
    private static function cache_key($prefix,$parts){return 'vti_'.sanitize_key($prefix).'_'.substr(hash('sha256',wp_json_encode(array(VTI_VERSION,$parts))),0,32);}
    private static function cached($key,$ttl,$callback){
        $value=get_transient($key);if(false!==$value)return $value;
        $value=call_user_func($callback);if(!is_wp_error($value))set_transient($key,$value,$ttl);return $value;
    }
    private static function user_agent(){
        $email=sanitize_email(self::option('contact_email',get_option('admin_email')));
        return 'VoyaseeTravelIntelligence/'.VTI_VERSION.' (+https://voyasee.com/; '.$email.')';
    }
    private static function http($url,$ttl=900,$json=true,$args=array()){
        $key=self::cache_key('http',array($url,$json));
        return self::cached($key,$ttl,function()use($url,$json,$args){
            $defaults=array('timeout'=>12,'redirection'=>3,'headers'=>array('Accept'=>$json?'application/json':'*/*','User-Agent'=>self::user_agent()));
            $r=wp_safe_remote_get($url,array_replace_recursive($defaults,$args));
            if(is_wp_error($r))return $r;
            $code=(int)wp_remote_retrieve_response_code($r);$body=wp_remote_retrieve_body($r);
            if($code<200||$code>=300)return new WP_Error('vti_http_'.$code,'Remote source returned HTTP '.$code,array('status'=>503,'url'=>$url));
            if(!$json)return $body;
            $d=json_decode($body,true);if(!is_array($d))return new WP_Error('vti_invalid_json','Remote source returned invalid JSON.',array('status'=>503,'url'=>$url));return $d;
        });
    }
    private static function post_text($url,$body,$ttl=86400){
        $key=self::cache_key('post',array($url,$body));
        return self::cached($key,$ttl,function()use($url,$body){
            $r=wp_safe_remote_post($url,array('timeout'=>18,'redirection'=>2,'headers'=>array('Accept'=>'application/json','User-Agent'=>self::user_agent(),'Content-Type'=>'application/x-www-form-urlencoded'),'body'=>array('data'=>$body)));
            if(is_wp_error($r))return $r;$code=(int)wp_remote_retrieve_response_code($r);if($code<200||$code>=300)return new WP_Error('vti_overpass_'.$code,'Nearby-place source returned HTTP '.$code,array('status'=>503));
            $d=json_decode(wp_remote_retrieve_body($r),true);return is_array($d)?$d:new WP_Error('vti_overpass_json','Nearby-place source returned invalid JSON.',array('status'=>503));
        });
    }
    private static function clean_error($v){return is_wp_error($v)?array('ok'=>false,'error'=>$v->get_error_message()):$v;}
    private static function num($v){return is_numeric($v)?(float)$v:null;}
    private static function excerpt($text,$length=280){$text=(string)$text;return function_exists('mb_substr')?mb_substr($text,0,$length,'UTF-8'):substr($text,0,$length);}
    private static function normalized_text($text){
        $text=html_entity_decode(wp_strip_all_tags((string)$text),ENT_QUOTES|ENT_HTML5,'UTF-8');
        $text=preg_replace('/\s+/u',' ',trim($text));
        return $text;
    }
    private static function exact_phrase($haystack,$needle){
        $haystack=self::normalized_text($haystack);$needle=trim((string)$needle);
        $haystack=function_exists('mb_strtolower')?mb_strtolower($haystack,'UTF-8'):strtolower($haystack);
        $needle=function_exists('mb_strtolower')?mb_strtolower($needle,'UTF-8'):strtolower($needle);
        if($needle==='')return false;
        return (bool)preg_match('/(?<![\pL\pN])'.preg_quote($needle,'/').'(?![\pL\pN])/u',$haystack);
    }
    private static function advisory_parse($html,$country){
        $text=self::normalized_text($html);
        $patterns=array(
            '/'.preg_quote($country,'/').'\s*-\s*Level\s*([1-4])\s*:\s*([^\r\n|]{3,100})/iu',
            '/Level\s*([1-4])\s*[:\-]\s*(Exercise Normal Precautions|Exercise Increased Caution|Reconsider Travel|Do Not Travel)/iu',
            '/Travel Advisory[^0-9]{0,80}Level\s*([1-4])\s*[:\-]?\s*([^\r\n|]{3,100})/iu'
        );
        foreach($patterns as $pattern){
            if(preg_match($pattern,$text,$m)){
                $label=trim(preg_replace('/\s+/u',' ',$m[2]));
                $label=preg_replace('/\s+(?:Travel Advisory Levels|Advisory summary|Date issued|Last Updated).*$/iu','',$label);
                $updated=null;
                if(preg_match('/(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}/i',$text,$dm))$updated=$dm[0];
                return array('level'=>(int)$m[1],'label'=>trim($label),'updated'=>$updated);
            }
        }
        return null;
    }
    private static function health_notice_match($ctx,$title,$description){
        $title=self::normalized_text($title);$description=self::normalized_text($description);
        $global=(bool)preg_match('/\b(global|worldwide|international travelers?|all travelers?)\b/i',$title);
        if($global)return array('match'=>true,'type'=>'global');
        $names=array_values(array_unique(array_filter(array_merge(array($ctx['name']),$ctx['aliases']))));
        foreach($names as $name){
            if(self::exact_phrase($title,$name))return array('match'=>true,'type'=>'title-country');
        }
        // Description-only matches are intentionally not accepted: RSS descriptions can contain
        // navigation and unrelated country lists. This trades recall for accuracy.
        return array('match'=>false,'type'=>'none');
    }
    public static function distance($lat1,$lon1,$lat2,$lon2){
        $r=6371;$p1=deg2rad((float)$lat1);$p2=deg2rad((float)$lat2);$dp=deg2rad((float)$lat2-(float)$lat1);$dl=deg2rad((float)$lon2-(float)$lon1);
        $a=sin($dp/2)*sin($dp/2)+cos($p1)*cos($p2)*sin($dl/2)*sin($dl/2);return $r*2*atan2(sqrt($a),sqrt(max(0,1-$a)));
    }
    public static function health(){
        $dependencies=array('weatherBridge'=>class_exists('VWB_Service'),'countryIntelligence'=>class_exists('VCI_Data'),'airportDataset'=>is_readable(VTI_DIR.'data/airports.min.json'),'timezoneGrid'=>is_readable(VTI_DIR.'data/timezone-grid.bin'));
        return array('ok'=>true,'ready'=>!in_array(false,$dependencies,true),'service'=>'Voyasee Travel Intelligence Bridge','version'=>VTI_VERSION,'generatedAt'=>self::now(),
            'dependencies'=>$dependencies,
            'modules'=>array('stateDepartment'=>self::enabled('state_department'),'govuk'=>self::enabled('govuk'),'cdc'=>self::enabled('cdc'),'usgs'=>self::enabled('usgs'),'gdacs'=>self::enabled('gdacs'),'eonet'=>self::enabled('eonet'),'nws'=>self::enabled('nws'),'nearby'=>self::enabled('overpass'),'firms'=>''!==trim((string)self::option('firms_map_key','')),'meteoalarm'=>''!==trim((string)self::option('meteoalarm_token',''))),
            'notice'=>'Official, live, curated and estimated fields are labelled separately. Visa, health, medicine, safety and entry decisions still require official verification.');
    }
    public static function diagnostics(){
        $h=self::health();$h['phpVersion']=PHP_VERSION;$h['wordpressVersion']=get_bloginfo('version');$h['cacheExample']=self::cache_key('diagnostic',array('ok'));$h['files']=array();
        foreach(array('airports.min.json','timezone-grid.bin','timezone-grid.json') as $f){$p=VTI_DIR.'data/'.$f;$h['files'][$f]=array('readable'=>is_readable($p),'bytes'=>is_readable($p)?filesize($p):0,'sha256'=>is_readable($p)?hash_file('sha256',$p):null);}return $h;
    }
    private static function country_context($country){
        $cc=strtoupper(trim((string)$country));
        if(isset(self::$ctx_cache[$cc]))return self::$ctx_cache[$cc];
        $out=array('code'=>$cc,'name'=>$cc,'alpha3'=>null,'aliases'=>array(),'data'=>null);
        if(class_exists('VCI_Data')){$d=VCI_Data::get_country($cc);if(!is_wp_error($d)){$core=$d['core']??array();$out['data']=$d;$out['code']=$d['code']??$cc;$out['name']=$core['names']['common']??$out['name'];$out['alpha3']=$core['codes']['alpha3']??null;$out['aliases']=array_values(array_filter(array_merge(array($core['names']['official']??null,$core['names']['native']??null),$core['names']['aliases']??array())));}}
        self::$ctx_cache[$cc]=$out;
        return $out;
    }
    private static function slug($name){
        $map=array('united states'=>'usa','united states of america'=>'usa','czechia'=>'czech-republic','cape verde'=>'cape-verde','cabo verde'=>'cape-verde','myanmar'=>'myanmar','burma'=>'myanmar','south korea'=>'south-korea','north korea'=>'north-korea','the gambia'=>'the-gambia','gambia'=>'the-gambia','ivory coast'=>'cote-d-ivoire','côte d’ivoire'=>'cote-d-ivoire','côte d\'ivoire'=>'cote-d-ivoire','democratic republic of the congo'=>'democratic-republic-of-the-congo','republic of the congo'=>'republic-of-the-congo','vatican city'=>'holy-see','holy see'=>'holy-see','timor-leste'=>'timor-leste','united kingdom'=>'united-kingdom','united arab emirates'=>'united-arab-emirates');
        $n=strtolower(trim(wp_strip_all_tags((string)$name)));return $map[$n]??sanitize_title($name);
    }
    public static function timezone($lat,$lon){
        $bin=VTI_DIR.'data/timezone-grid.bin';$metaPath=VTI_DIR.'data/timezone-grid.json';
        if(!is_readable($bin)||!is_readable($metaPath))return array('id'=>'UTC','method'=>'fallback','confidence'=>'low');
        if(null===self::$tzmeta){$m=json_decode(file_get_contents($metaPath),true);self::$tzmeta=is_array($m)?$m:array();}
        $meta=self::$tzmeta['meta']??array();$zones=self::$tzmeta['zones']??array();$step=(float)($meta['step']??0.5);$lc=(int)($meta['latCount']??360);$oc=(int)($meta['lonCount']??720);
        $iy=max(0,min($lc-1,(int)floor(((float)$lat+90)/$step)));$ix=max(0,min($oc-1,(int)floor(((float)$lon+180)/$step)));$offset=2*($iy*$oc+$ix);
        $fh=fopen($bin,'rb');if(!$fh)return array('id'=>'UTC','method'=>'fallback','confidence'=>'low');fseek($fh,$offset);$bytes=fread($fh,2);fclose($fh);if(strlen($bytes)!==2)return array('id'=>'UTC','method'=>'fallback','confidence'=>'low');$u=unpack('vindex',$bytes);$id=$zones[(int)($u['index']??0)]??'UTC';if(!$id)$id='UTC';
        return array('id'=>$id,'method'=>'coordinate-grid-0.5deg','confidence'=>'medium','gridResolutionKmApprox'=>55,'source'=>'timezonefinder / timezone-boundary-builder');
    }
    private static function load_airports(){if(null!==self::$airports)return self::$airports;$p=VTI_DIR.'data/airports.min.json';$d=is_readable($p)?json_decode(file_get_contents($p),true):array();self::$airports=$d['airports']??array();return self::$airports;}
    public static function nearest_airports($lat,$lon,$limit=5){
        $key=self::cache_key('airports',array(round($lat,2),round($lon,2),$limit));
        return self::cached($key,DAY_IN_SECONDS,function()use($lat,$lon,$limit){
            // Bounding-box pre-filter cuts the full 8 000-airport dataset down to
            // ~50-200 candidates before the exact Haversine calculation runs.
            $latDelta=10.8;// 1200 km / 111 km per degree
            $cosLat=cos(deg2rad((float)$lat));
            $lonDelta=$cosLat>0.001?min(180,1200/(111.0*$cosLat)):180;
            $rows=array();
            foreach(self::load_airports() as $a){
                if(abs($a['lat']-(float)$lat)>$latDelta||abs($a['lon']-(float)$lon)>$lonDelta)continue;
                $d=self::distance($lat,$lon,$a['lat'],$a['lon']);
                if($d>1200)continue;
                $a['distanceKm']=round($d,1);$rows[]=$a;
            }
            usort($rows,function($a,$b){return $a['distanceKm']<=>$b['distanceKm'];});
            return array_slice($rows,0,$limit);
        });
    }
    private static function state_department($ctx){
        if(!self::enabled('state_department'))return array('status'=>'disabled');
        $slug=self::slug($ctx['name']);
        $canonical_map=array('usa'=>'united-states','holy-see'=>'vatican-city','cote-d-ivoire'=>'cote-divoire','the-gambia'=>'gambia');
        $canonical=$canonical_map[$slug]??$slug;
        // Only use country-specific URLs for parsing. The generic list page
        // (travel-advisories.html) lists all countries and would match the first
        // country alphabetically, not the destination being queried.
        $urls=array(
            'https://travel.state.gov/en/international-travel/travel-advisories/'.rawurlencode($canonical).'.html',
            'https://travel.state.gov/content/travel/en/traveladvisories/traveladvisories/'.rawurlencode($slug).'-travel-advisory.html',
        );
        $last_error=null;
        foreach($urls as $index=>$url){
            // Short cache on country-specific pages so parse failures expire quickly.
            $html=self::http($url,30*MINUTE_IN_SECONDS,false);
            if(is_wp_error($html)){$last_error=$html->get_error_message();continue;}
            $parsed=self::advisory_parse($html,$ctx['name']);
            if(!$parsed){
                foreach($ctx['aliases'] as $alias){$parsed=self::advisory_parse($html,$alias);if($parsed)break;}
            }
            if($parsed){
                return array('status'=>'available','level'=>$parsed['level'],'label'=>$parsed['label'],'updated'=>$parsed['updated'],'country'=>$ctx['name'],'url'=>$urls[0],'source'=>'U.S. Department of State','audience'=>'U.S. citizens','parsedFrom'=>$url,'confidence'=>'official');
            }
        }
        error_log('[VTI v'.VTI_VERSION.'] State Dept advisory could not be parsed for: '.$ctx['name'].' (slug: '.$slug.')');
        return array('status'=>'unavailable','message'=>'The official advisory could not be parsed automatically. No level has been estimated.','error'=>$last_error,'url'=>$urls[0],'source'=>'U.S. Department of State','confidence'=>'unavailable');
    }
    private static function govuk($ctx){
        if(!self::enabled('govuk'))return array('status'=>'disabled');
        $slug=self::slug($ctx['name']);
        $api='https://www.gov.uk/api/content/foreign-travel-advice/'.rawurlencode($slug);
        $d=self::http($api,3*HOUR_IN_SECONDS,true);
        $web='https://www.gov.uk/foreign-travel-advice/'.rawurlencode($slug);
        if(is_wp_error($d))return array('status'=>'unavailable','error'=>$d->get_error_message(),'url'=>$web,'source'=>'UK Foreign, Commonwealth & Development Office');
        $s=$d['details']['alert_status']??array();$status='none';
        if(in_array('avoid_all_travel',$s,true)||in_array('avoid_all_travel_to_whole_country',$s,true))$status='avoid-all';
        elseif(in_array('avoid_all_but_essential_travel',$s,true)||in_array('avoid_all_but_essential_travel_to_whole_country',$s,true))$status='essential-only';
        elseif($s)$status='regional-warning';
        $summary='No nationwide avoid-travel flag was detected. Read the full official page for safety, entry and regional advice.';
        if($status==='avoid-all')$summary='FCDO advises against all travel. Read the full official page for scope and exceptions.';
        elseif($status==='essential-only')$summary='FCDO advises against all but essential travel. Read the full official page for scope and exceptions.';
        elseif($status==='regional-warning')$summary='FCDO advises against travel to specified areas. Open the official regional-risk guidance for the exact locations.';
        return array('status'=>'available','alertStatus'=>$s,'summaryStatus'=>$status,'summary'=>$summary,'latestChange'=>self::normalized_text($d['details']['change_description']??''),'updated'=>$d['public_updated_at']??null,'title'=>$d['title']??$ctx['name'],'url'=>$web,'source'=>'UK FCDO','audience'=>'British nationals','confidence'=>'official');
    }
    public static function advisories($country){$ctx=self::country_context($country);return array('country'=>$ctx['name'],'us'=>self::state_department($ctx),'uk'=>self::govuk($ctx),'generatedAt'=>self::now(),'notice'=>'Advice is issued for each government’s own nationals and can include regional exceptions. Read the official page before making a decision.');}
    public static function health_notices($country){
        $ctx=self::country_context($country);
        if(!self::enabled('cdc'))return array('status'=>'disabled','notices'=>array());
        $url='https://wwwnc.cdc.gov/travel/rss/notices.xml';
        $xml=self::http($url,3*HOUR_IN_SECONDS,false);
        if(is_wp_error($xml))return array('status'=>'unavailable','notices'=>array(),'url'=>'https://wwwnc.cdc.gov/travel/notices','error'=>$xml->get_error_message());
        libxml_use_internal_errors(true);$sx=simplexml_load_string($xml,'SimpleXMLElement',LIBXML_NOCDATA);$rows=array();$seen=array();
        if($sx&&isset($sx->channel->item)){
            foreach($sx->channel->item as $item){
                $title=trim((string)$item->title);$desc=trim(wp_strip_all_tags((string)$item->description));$link=trim((string)$item->link);
                $match=self::health_notice_match($ctx,$title,$desc);if(empty($match['match']))continue;
                $dedupe=$link?:strtolower($title);if(isset($seen[$dedupe]))continue;$seen[$dedupe]=1;
                $level=null;if(preg_match('/Level\s*([1-4])/i',$title,$m))$level=(int)$m[1];
                $rows[]=array('title'=>$title,'summary'=>self::excerpt($desc,280),'published'=>(string)$item->pubDate,'url'=>$link,'level'=>$level,'matchType'=>$match['type'],'source'=>'CDC Travelers’ Health');
                if(count($rows)>=3)break;
            }
        }
        return array('status'=>'available','country'=>$ctx['name'],'notices'=>$rows,'url'=>'https://wwwnc.cdc.gov/travel/notices','source'=>'CDC Travelers’ Health','generatedAt'=>self::now(),'matchingPolicy'=>'Exact country name in notice title or explicitly global notice. RSS description-only matches are rejected to prevent false country alerts.');
    }
    private static function usgs($lat,$lon){
        if(!self::enabled('usgs'))return array('status'=>'disabled','events'=>array());$start=gmdate('Y-m-d',time()-30*DAY_IN_SECONDS);$url='https://earthquake.usgs.gov/fdsnws/event/1/query?'.http_build_query(array('format'=>'geojson','starttime'=>$start,'latitude'=>$lat,'longitude'=>$lon,'maxradiuskm'=>1000,'minmagnitude'=>2.5,'orderby'=>'time','limit'=>100));$d=self::http($url,10*MINUTE_IN_SECONDS,true);if(is_wp_error($d))return array('status'=>'unavailable','events'=>array(),'error'=>$d->get_error_message());$out=array();foreach($d['features']??array() as $f){$c=$f['geometry']['coordinates']??array();$p=$f['properties']??array();if(!isset($c[0],$c[1])||!is_numeric($c[0])||!is_numeric($c[1])||!is_numeric($p['mag']??null))continue;$km=self::distance($lat,$lon,$c[1],$c[0]);$mag=(float)$p['mag'];$show=($mag>=6&&$km<=1000)||($mag>=5&&$km<=700)||($mag>=4&&$km<=350)||($mag>=2.5&&$km<=80);if(!$show)continue;$sev=$mag>=6?'high':($mag>=5?'medium':'low');$out[]=array('id'=>$f['id']??null,'magnitude'=>$mag,'distanceKm'=>round($km,1),'depthKm'=>isset($c[2])?round((float)$c[2],1):null,'place'=>$p['place']??null,'occurredAt'=>isset($p['time'])?gmdate('c',(int)($p['time']/1000)):null,'updatedAt'=>isset($p['updated'])?gmdate('c',(int)($p['updated']/1000)):null,'alert'=>$p['alert']??null,'tsunami'=>!empty($p['tsunami']),'significance'=>$p['sig']??null,'severity'=>$sev,'url'=>$p['url']??null,'source'=>'USGS');}
        usort($out,function($a,$b){return strcmp($b['occurredAt']??'',$a['occurredAt']??'');});return array('status'=>'available','events'=>array_slice($out,0,8),'source'=>'USGS Earthquake Hazards Program');
    }
    private static function gdacs($lat,$lon){
        if(!self::enabled('gdacs'))return array('status'=>'disabled','events'=>array());$from=gmdate('Y-m-d',time()-30*DAY_IN_SECONDS);$to=gmdate('Y-m-d');$url='https://www.gdacs.org/gdacsapi/api/events/geteventlist/SEARCH?'.http_build_query(array('eventlist'=>'EQ;TC;FL;WF;VO','fromdate'=>$from,'todate'=>$to,'alertlevel'=>'green;orange;red','pagesize'=>100));$d=self::http($url,20*MINUTE_IN_SECONDS,true);if(is_wp_error($d))return array('status'=>'unavailable','events'=>array(),'error'=>$d->get_error_message());$features=$d['features']??($d['data']??array());$out=array();foreach((array)$features as $f){$prop=$f['properties']??$f;$geom=$f['geometry']['coordinates']??array();$la=$prop['latitude']??($prop['lat']??($geom[1]??null));$lo=$prop['longitude']??($prop['lon']??($geom[0]??null));if(!is_numeric($la)||!is_numeric($lo))continue;$km=self::distance($lat,$lon,$la,$lo);if($km>1200)continue;$alert=strtolower((string)($prop['alertlevel']??$prop['alertLevel']??$prop['alert']??'green'));$out[]=array('id'=>$prop['eventid']??$prop['eventId']??$f['id']??null,'type'=>$prop['eventtype']??$prop['eventType']??null,'name'=>wp_strip_all_tags((string)($prop['name']??$prop['eventname']??'Disaster event')),'alert'=>$alert,'distanceKm'=>round($km,1),'occurredAt'=>$prop['fromdate']??$prop['date']??$prop['datetime']??null,'url'=>$prop['url']??'https://www.gdacs.org/','source'=>'GDACS','severity'=>$alert==='red'?'high':($alert==='orange'?'medium':'low'));}
        usort($out,function($a,$b){$rank=array('high'=>3,'medium'=>2,'low'=>1);return ($rank[$b['severity']]??0)<=>($rank[$a['severity']]??0);});return array('status'=>'available','events'=>array_slice($out,0,8),'source'=>'Global Disaster Alert and Coordination System');
    }
    private static function eonet($lat,$lon){
        if(!self::enabled('eonet'))return array('status'=>'disabled','events'=>array());$url='https://eonet.gsfc.nasa.gov/api/v3/events?status=open&days=30&limit=100';$d=self::http($url,30*MINUTE_IN_SECONDS,true);if(is_wp_error($d))return array('status'=>'unavailable','events'=>array(),'error'=>$d->get_error_message());$out=array();foreach($d['events']??array() as $e){$g=$e['geometry']??array();if(!$g)continue;$last=end($g);$c=$last['coordinates']??array();if(($last['type']??'')!=='Point'||!isset($c[0],$c[1])||!is_numeric($c[0])||!is_numeric($c[1]))continue;$km=self::distance($lat,$lon,$c[1],$c[0]);if($km>1200)continue;$cats=array_map(function($x){return $x['title']??'';},$e['categories']??array());$out[]=array('id'=>$e['id']??null,'title'=>$e['title']??'Natural event','categories'=>array_values(array_filter($cats)),'distanceKm'=>round($km,1),'occurredAt'=>$last['date']??null,'url'=>$e['link']??'https://eonet.gsfc.nasa.gov/','source'=>'NASA EONET','severity'=>$km<150?'medium':'low');}
        usort($out,function($a,$b){return $a['distanceKm']<=>$b['distanceKm'];});return array('status'=>'available','events'=>array_slice($out,0,6),'source'=>'NASA EONET');
    }
    private static function firms($lat,$lon){
        $key=trim((string)self::option('firms_map_key',''));if($key==='')return array('status'=>'disabled','reason'=>'No optional FIRMS MAP_KEY configured','detections'=>array());$delta=2.0;$box=implode(',',array(max(-180,$lon-$delta),max(-90,$lat-$delta),min(180,$lon+$delta),min(90,$lat+$delta)));$url='https://firms.modaps.eosdis.nasa.gov/api/area/csv/'.rawurlencode($key).'/VIIRS_NOAA20_NRT/'.$box.'/1';$csv=self::http($url,30*MINUTE_IN_SECONDS,false);if(is_wp_error($csv))return array('status'=>'unavailable','detections'=>array(),'error'=>$csv->get_error_message());$lines=preg_split('/\r\n|\r|\n/',trim($csv));if(count($lines)<2)return array('status'=>'available','detections'=>array(),'count'=>0,'source'=>'NASA FIRMS');$head=str_getcsv(array_shift($lines));$out=array();foreach($lines as $line){$v=str_getcsv($line);if(count($v)!==count($head))continue;$r=array_combine($head,$v);$la=$r['latitude']??null;$lo=$r['longitude']??null;if(!is_numeric($la)||!is_numeric($lo))continue;$km=self::distance($lat,$lon,$la,$lo);if($km>250)continue;$out[]=array('distanceKm'=>round($km,1),'date'=>$r['acq_date']??null,'time'=>$r['acq_time']??null,'confidence'=>$r['confidence']??null,'frp'=>isset($r['frp'])?(float)$r['frp']:null,'source'=>'NASA FIRMS');if(count($out)>=50)break;}return array('status'=>'available','count'=>count($out),'detections'=>array_slice($out,0,10),'source'=>'NASA FIRMS','notice'=>'Satellite thermal detections are not the same as a confirmed dangerous wildfire.');
    }
    private static function nws($lat,$lon,$country){
        if(strtoupper($country)!=='US'||!self::enabled('nws'))return array('status'=>'not-applicable','alerts'=>array());$url='https://api.weather.gov/alerts/active?point='.rawurlencode($lat.','.$lon);$d=self::http($url,5*MINUTE_IN_SECONDS,true);if(is_wp_error($d))return array('status'=>'unavailable','alerts'=>array(),'error'=>$d->get_error_message());$out=array();foreach($d['features']??array() as $f){$p=$f['properties']??array();$out[]=array('id'=>$p['id']??$f['id']??null,'event'=>$p['event']??null,'headline'=>$p['headline']??null,'severity'=>$p['severity']??null,'urgency'=>$p['urgency']??null,'certainty'=>$p['certainty']??null,'onset'=>$p['onset']??null,'expires'=>$p['expires']??null,'instruction'=>self::excerpt(wp_strip_all_tags($p['instruction']??''),400),'url'=>$p['@id']??$f['id']??'https://www.weather.gov/','source'=>'U.S. National Weather Service');if(count($out)>=8)break;}return array('status'=>'available','alerts'=>$out,'source'=>'U.S. National Weather Service');
    }
    private static function meteoalarm($country){
        $token=trim((string)self::option('meteoalarm_token',''));
        $cc=strtoupper((string)$country);
        $supported=array('AD','AM','AT','BA','BE','BG','CH','CY','CZ','DE','DK','EE','ES','FI','FR','GB','GR','HR','HU','IE','IL','IS','IT','LT','LU','LV','MD','ME','MK','MT','NL','NO','PL','PT','RO','RS','SE','SI','SK','UA');
        if($token===''||!in_array($cc,$supported,true))return array('status'=>$token===''?'disabled':'not-applicable','alerts'=>array());
        $loc=$cc==='GB'?'UK':($cc==='GR'?'EL':$cc);
        $url='https://api.meteoalarm.org/edr/v1/collections/warnings/locations/'.rawurlencode($loc).'?'.http_build_query(array('f'=>'geojson','language'=>'en','token'=>$token));
        $d=self::http($url,10*MINUTE_IN_SECONDS,true);
        if(is_wp_error($d))return array('status'=>'unavailable','alerts'=>array(),'error'=>$d->get_error_message(),'url'=>'https://www.meteoalarm.org/');
        $out=array();foreach($d['features']??array() as $f){$p=$f['properties']??array();$cap=$p['cap']??$p;$level=$p['awareness_level']??$p['awarenessLevel']??null;$event=$p['event']??$cap['event']??$p['awareness_type']??'Weather warning';$out[]=array('id'=>$f['id']??$p['identifier']??null,'event'=>is_array($event)?wp_json_encode($event):wp_strip_all_tags((string)$event),'headline'=>wp_strip_all_tags((string)($p['headline']??$cap['headline']??'')),'severity'=>$p['severity']??$cap['severity']??$level,'onset'=>$p['onset']??$cap['onset']??null,'expires'=>$p['expires']??$cap['expires']??null,'url'=>$p['web']??'https://www.meteoalarm.org/','source'=>'MeteoAlarm');if(count($out)>=10)break;}
        return array('status'=>'available','alerts'=>$out,'source'=>'MeteoAlarm','attribution'=>'MeteoAlarm / EUMETNET members, CC BY 4.0');
    }
    public static function hazards($lat,$lon,$country=''){
        $u=self::usgs($lat,$lon);$g=self::gdacs($lat,$lon);$e=self::eonet($lat,$lon);$f=self::firms($lat,$lon);$n=self::nws($lat,$lon,$country);$m=self::meteoalarm($country);$severity='none';$rank=array('none'=>0,'low'=>1,'medium'=>2,'high'=>3);
        foreach(array_merge($u['events']??array(),$g['events']??array(),$e['events']??array()) as $x){if(($rank[$x['severity']??'none']??0)>$rank[$severity])$severity=$x['severity'];}
        $officialAlerts=array_merge($n['alerts']??array(),$m['alerts']??array());
        foreach($officialAlerts as $alert){$raw=strtolower((string)($alert['severity']??''));$alertSeverity=(false!==strpos($raw,'extreme')||false!==strpos($raw,'severe')||in_array($raw,array('4','red'),true))?'high':((false!==strpos($raw,'moderate')||in_array($raw,array('3','orange'),true))?'medium':'low');if(($rank[$alertSeverity]??0)>$rank[$severity])$severity=$alertSeverity;}
        if(($f['count']??0)>8&&$rank[$severity]<2)$severity='medium';
        $states=array();foreach(array($u,$g,$e,$f,$n,$m) as $module){$st=$module['status']??null;if($st&&!in_array($st,array('disabled','not-applicable'),true))$states[]=$st;}
        $available=count(array_filter($states,function($x){return $x==='available';}));$failed=count(array_filter($states,function($x){return $x==='unavailable';}));
        $coverage=$available===0?'unavailable':($failed>0?'partial':'complete');
        return array('overallSeverity'=>$severity,'coverageStatus'=>$coverage,'earthquakes'=>$u,'gdacs'=>$g,'eonet'=>$e,'fires'=>$f,'officialWeatherAlerts'=>array('status'=>$officialAlerts?'available':(($n['status']??'not-applicable')==='unavailable'||($m['status']??'not-applicable')==='unavailable'?'partial':'not-applicable'),'alerts'=>$officialAlerts,'sources'=>array_values(array_filter(array(!empty($n['alerts'])?'U.S. National Weather Service':null,!empty($m['alerts'])?'MeteoAlarm':null)))),'nws'=>$n,'meteoalarm'=>$m,'generatedAt'=>self::now(),'notice'=>'Proximity does not prove destination impact. Satellite fire detections are not confirmed dangerous wildfires. Missing feeds do not mean there is no hazard. Follow local authorities and official emergency instructions.');
    }
    public static function nearby($lat,$lon,$radius=5000){
        if(!self::enabled('overpass'))return array('status'=>'disabled','places'=>array());
        $radius=max(1000,min(15000,(int)$radius));
        $q='[out:json][timeout:18];('.
            'nwr(around:'.$radius.','.$lat.','.$lon.')['.'"amenity"~"hospital|clinic|doctors|pharmacy|police|atm|bank"'.'];'.
            'nwr(around:'.$radius.','.$lat.','.$lon.')['.'"shop"="supermarket"'.'];'.
            'nwr(around:'.$radius.','.$lat.','.$lon.')['.'"tourism"="information"'.'];'.
            'nwr(around:'.$radius.','.$lat.','.$lon.')['.'"railway"~"station|halt"'.'];'.
            'nwr(around:'.$radius.','.$lat.','.$lon.')['.'"public_transport"~"station|platform"'.'];'.
            ');out center tags 80;';
        $endpoints=array('https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter');
        $d=null;$errors=array();
        foreach($endpoints as $endpoint){$candidate=self::post_text($endpoint,$q,DAY_IN_SECONDS);if(!is_wp_error($candidate)){$d=$candidate;break;}$errors[]=$candidate->get_error_message();}
        if(!is_array($d))return array('status'=>'unavailable','places'=>array(),'error'=>implode(' | ',$errors),'source'=>'OpenStreetMap / Overpass','searchLinks'=>array(
            'hospitals'=>'https://www.openstreetmap.org/search?query='.rawurlencode('hospital near '.$lat.','.$lon),
            'pharmacies'=>'https://www.openstreetmap.org/search?query='.rawurlencode('pharmacy near '.$lat.','.$lon),
            'atms'=>'https://www.openstreetmap.org/search?query='.rawurlencode('ATM near '.$lat.','.$lon),
            'transport'=>'https://www.openstreetmap.org/search?query='.rawurlencode('station near '.$lat.','.$lon)
        ));
        $out=array();foreach($d['elements']??array() as $el){$t=$el['tags']??array();$la=$el['lat']??($el['center']['lat']??null);$lo=$el['lon']??($el['center']['lon']??null);if(!is_numeric($la)||!is_numeric($lo))continue;$type=$t['amenity']??$t['shop']??$t['tourism']??$t['railway']??$t['public_transport']??'place';$name=$t['name:en']??$t['name']??ucwords(str_replace('_',' ',$type));$out[]=array('id'=>($el['type']??'x').':'.($el['id']??''),'type'=>$type,'name'=>$name,'distanceKm'=>round(self::distance($lat,$lon,$la,$lo),2),'lat'=>(float)$la,'lon'=>(float)$lo,'openingHours'=>$t['opening_hours']??null,'phone'=>$t['contact:phone']??$t['phone']??null,'website'=>$t['contact:website']??$t['website']??null);}
        usort($out,function($a,$b){return $a['distanceKm']<=>$b['distanceKm'];});$seen=array();$clean=array();foreach($out as $x){$k=$x['type'].'|'.strtolower($x['name']);if(isset($seen[$k]))continue;$seen[$k]=1;$clean[]=$x;if(count($clean)>=30)break;}
        return array('status'=>'available','places'=>$clean,'radiusM'=>$radius,'source'=>'OpenStreetMap contributors via Overpass','attribution'=>'© OpenStreetMap contributors, ODbL');
    }
    private static function weather($lat,$lon){
        if(!class_exists('VWB_Service'))return array('status'=>'unavailable','error'=>'Voyasee Weather Bridge is not active.');$parts=array();
        foreach(array('current'=>function()use($lat,$lon){return VWB_Service::get_current($lat,$lon);},'forecast'=>function()use($lat,$lon){return VWB_Service::get_forecast($lat,$lon,5);},'hourly'=>function()use($lat,$lon){return VWB_Service::get_hourly($lat,$lon,24);},'airQuality'=>function()use($lat,$lon){return VWB_Service::get_air_quality($lat,$lon);},'airQualityForecast'=>function()use($lat,$lon){return VWB_Service::get_air_quality_forecast($lat,$lon,24);},'uv'=>function()use($lat,$lon){return VWB_Service::get_uv($lat,$lon);},'alerts'=>function()use($lat,$lon){return VWB_Service::get_alerts($lat,$lon);} ) as $k=>$fn){$v=call_user_func($fn);$parts[$k]=self::clean_error($v);}return array('status'=>'available','parts'=>$parts);
    }
    private static function country_data($country){
        if(!class_exists('VCI_Data'))return array('status'=>'unavailable','error'=>'Voyasee Country Intelligence is not active.');$year=(int)gmdate('Y');$c=VCI_Data::get_country($country,$year);if(is_wp_error($c))return array('status'=>'unavailable','error'=>$c->get_error_message());return array('status'=>'available','country'=>$c);
    }
    private static function official_links($ctx,$passport){
        $slug=self::slug($ctx['name']);$passport=strtoupper($passport);$passportLinks=array(
            'IN'=>array('label'=>'India Ministry of External Affairs','url'=>'https://www.mea.gov.in/'),
            'US'=>array('label'=>'U.S. Department of State','url'=>'https://travel.state.gov/en/international-travel.html'),
            'GB'=>array('label'=>'UK foreign travel advice','url'=>'https://www.gov.uk/foreign-travel-advice'),
            'CA'=>array('label'=>'Government of Canada travel advice','url'=>'https://travel.gc.ca/travelling/advisories'),
            'AU'=>array('label'=>'Australian Smartraveller','url'=>'https://www.smartraveller.gov.au/destinations'),
            'EU'=>array('label'=>'EU travel and consular protection','url'=>'https://consular-protection.ec.europa.eu/index_en'),
        );
        $authority=$passportLinks[$passport]??array('label'=>'Your passport country foreign ministry','url'=>null);
        return array('usAdvisory'=>'https://travel.state.gov/en/international-travel/travel-advisories.html','ukAdvice'=>'https://www.gov.uk/foreign-travel-advice/'.$slug,'cdc'=>'https://wwwnc.cdc.gov/travel/destinations/list','usEmbassyDirectory'=>'https://www.usembassy.gov/','passportAuthority'=>$authority,'notice'=>'Use direct government immigration, embassy, customs and medicine sources. No exact visa result is generated when a verified official source is unavailable.');
    }
    private static function activity_matrix($weather,$holidays,$aqSensitive=false){
        $days=$weather['parts']['forecast']['forecastDaily']??array();$out=array();$holidayDates=array();foreach($holidays as $h){if(!empty($h['date']))$holidayDates[$h['date']]=$h;}
        $aqByDate=array();$aqRows=$weather['parts']['airQualityForecast']['airQualityForecast']??array();$offset=0;if(!empty($days[0]['timezoneOffsetSec']))$offset=(int)$days[0]['timezoneOffsetSec'];
        foreach((array)$aqRows as $row){$when=$row['forecastAt']??null;$value=$row['usAqiEstimate']??null;if(!$when||!is_numeric($value))continue;$ts=strtotime($when);if(!$ts)continue;$date=gmdate('Y-m-d',$ts+$offset);if(!isset($aqByDate[$date]))$aqByDate[$date]=array();$aqByDate[$date][]=(float)$value;}
        $currentAq=$weather['parts']['airQuality']['airQuality']['usAqiEstimate']??null;
        foreach(array_slice((array)$days,0,5) as $idx=>$d){
            $rain=$d['precipitationProbabilityPct']??null;$max=$d['tempMaxC']??null;$uv=$d['uvIndex']??null;$date=$d['date']??null;$aq=null;
            if($date&&isset($aqByDate[$date])&&$aqByDate[$date])$aq=round(max($aqByDate[$date]));elseif($idx===0&&is_numeric($currentAq))$aq=round($currentAq);
            $score=100;$reasons=array();if(is_numeric($rain)){$score-=min(40,(float)$rain*.4);if($rain>=60)$reasons[]='High peak 3-hour rain chance';}if(is_numeric($max)&&$max>=35){$score-=20;$reasons[]='Strong heat';}if(is_numeric($uv)&&$uv>=8){$score-=12;$reasons[]='Very high UV';}if(is_numeric($aq)&&$aq>=($aqSensitive?80:101)){$score-=18;$reasons[]='Air-quality caution';}if(isset($holidayDates[$date])){$score-=8;$reasons[]='Public holiday';}$score=max(0,round($score));$activity=$score>=80?'Outdoor sightseeing':($score>=60?'Flexible mixed day':(is_numeric($rain)&&$rain>=60?'Museums and covered attractions':'Short outdoor sessions'));
            $out[]=array('date'=>$date,'condition'=>$d['condition']['text']??null,'tempMinC'=>$d['tempMinC']??null,'tempMaxC'=>$max,'rainPct'=>$rain,'rainMetric'=>'Peak 3-hour probability','forecastSlotCount'=>$d['forecastSlotCount']??null,'uv'=>$uv,'aqi'=>$aq,'aqiMetric'=>$aq===null?null:'Peak forecast estimated US AQI','holiday'=>isset($holidayDates[$date])?($holidayDates[$date]['localName']??$holidayDates[$date]['name']??'Public holiday'):null,'outdoorScore'=>$score,'recommendation'=>$activity,'reasons'=>$reasons);
        }
        return $out;
    }
    private static function aq_trend($weather){
        $rows=$weather['parts']['airQualityForecast']['airQualityForecast']??array();$vals=array();foreach(array_slice((array)$rows,0,12) as $r){$v=$r['usAqiEstimate']??null;if(is_numeric($v))$vals[]=(float)$v;}if(count($vals)<3)return array('status'=>'unavailable','direction'=>'unknown','change'=>null);$first=array_sum(array_slice($vals,0,min(3,count($vals))))/min(3,count($vals));$last=array_sum(array_slice($vals,-min(3,count($vals))))/min(3,count($vals));$change=round($last-$first);$dir=$change>=10?'worsening':($change<=-10?'improving':'stable');return array('status'=>'available','direction'=>$dir,'change'=>$change,'first'=>round($first),'later'=>round($last),'notice'=>'Trend is based on forecast US AQI estimates and is not an official 24-hour AQI.');
    }
    private static function data_available($value){return is_array($value)&&(($value['status']??'')==='available'||!empty($value['ok']));}
    private static function readiness($report,$p){
        $dims=array();$availableMax=0;$earned=0;$scorableMax=80;
        $us=$report['advisories']['us']??array();$uk=$report['advisories']['uk']??array();$haz=$report['hazards']['overallSeverity']??'none';$hazCoverage=$report['hazards']['coverageStatus']??'unavailable';
        $usOk=($us['status']??'')==='available';$ukOk=($uk['status']??'')==='available';$hasAdvice=$usOk||$ukOk;
        if($hasAdvice||$hazCoverage!=='unavailable'){
            $safety=15;$confidence='high';$notes=array();
            if($usOk){if(($us['level']??0)>=4)$safety=2;elseif(($us['level']??0)===3)$safety=6;elseif(($us['level']??0)===2)$safety=11;}else{$safety=min($safety,10);$confidence='partial';$notes[]='U.S. advisory unavailable';}
            if($ukOk){if(($uk['summaryStatus']??'none')==='avoid-all')$safety=min($safety,3);elseif(($uk['summaryStatus']??'none')==='essential-only')$safety=min($safety,7);elseif(($uk['summaryStatus']??'none')==='regional-warning'){$safety=min($safety,11);$notes[]='UK regional warning';}}else{$safety=min($safety,11);$confidence='partial';$notes[]='UK advice unavailable';}
            if($haz==='high'){$safety=max(0,$safety-5);$notes[]='high-severity hazard signal';}elseif($haz==='medium'){$safety=max(0,$safety-2);$notes[]='medium hazard signal';}
            if($hazCoverage==='partial'){$safety=min($safety,12);$confidence='partial';$notes[]='partial hazard coverage';}elseif($hazCoverage==='unavailable'){$safety=min($safety,11);$confidence='partial';$notes[]='hazard coverage unavailable';}
            $reason=$notes?implode('; ',$notes):'No top-level high-risk signal detected in the integrated official and hazard sources.';
            $dims['safety']=array('score'=>$safety,'max'=>15,'status'=>'scored','confidence'=>$confidence,'reason'=>$reason);$earned+=$safety;$availableMax+=15;
        }else{$dims['safety']=array('score'=>null,'max'=>15,'status'=>'unavailable','confidence'=>'unavailable','reason'=>'Official advisory and hazard sources were unavailable.');}
        $current=$report['weather']['parts']['current']['current']??array();$forecast=$report['activityMatrix']??array();if($current||$forecast){$weatherScore=20;$t=$current['tempC']??null;if(is_numeric($t)&&($t>=36||$t<=-5))$weatherScore-=5;$avgRain=0;$n=0;foreach($forecast as $d){if(is_numeric($d['rainPct']??null)){$avgRain+=$d['rainPct'];$n++;}}if($n&&$avgRain/$n>=60)$weatherScore-=6;$alerts=$report['hazards']['officialWeatherAlerts']['alerts']??array();if($alerts)$weatherScore-=6;$weatherScore=max(0,$weatherScore);$dims['weather']=array('score'=>$weatherScore,'max'=>20,'status'=>'scored','confidence'=>'high','reason'=>$alerts?'Official weather alert active':'Five-day conditions assessed using destination-local forecast days');$earned+=$weatherScore;$availableMax+=20;}else{$dims['weather']=array('score'=>null,'max'=>20,'status'=>'unavailable','confidence'=>'unavailable','reason'=>'Weather data unavailable.');}
        $aq=$report['weather']['parts']['airQuality']['airQuality']['usAqiEstimate']??null;$notices=$report['healthNotices']['notices']??array();$uv=$report['weather']['parts']['uv']['uv']['uvIndex']??($report['weather']['parts']['uv']['uvIndex']??null);if(is_numeric($aq)||$notices||is_numeric($uv)){$health=15;$threshold=!empty($p['aq_sensitive'])?80:101;if(is_numeric($aq)&&$aq>=$threshold)$health-=5;$countryNotice=false;$globalNotice=false;foreach($notices as $notice){if(($notice['matchType']??'')==='title-country')$countryNotice=true;elseif(($notice['matchType']??'')==='global')$globalNotice=true;}if($countryNotice)$health-=4;elseif($globalNotice)$health-=2;if(is_numeric($uv)&&$uv>=8)$health-=2;$health=max(0,$health);$noticeReason=$countryNotice?'Verified country-title CDC notice matched':($globalNotice?'Explicitly global CDC notice matched':'AQI, UV and verified health-notice matching checked');$dims['health']=array('score'=>$health,'max'=>15,'status'=>'scored','confidence'=>'medium','reason'=>$noticeReason);$earned+=$health;$availableMax+=15;}else{$dims['health']=array('score'=>null,'max'=>15,'status'=>'unavailable','confidence'=>'unavailable','reason'=>'Health-environment data unavailable.');}
        $dims['entry']=array('score'=>null,'max'=>20,'status'=>'verify','confidence'=>'official-check-required','reason'=>'Exact passport, purpose, date and route rules require official immigration and airline verification.');
        if(($report['country']['status']??'')==='available'){$timing=10;if(!empty($report['holidaySoon']))$timing-=2;$dims['timing']=array('score'=>$timing,'max'=>10,'status'=>'scored','confidence'=>'medium','reason'=>!empty($report['holidaySoon'])?'A national public holiday falls within 21 days':'No near-term national holiday detected');$earned+=$timing;$availableMax+=10;}else{$dims['timing']=array('score'=>null,'max'=>10,'status'=>'unavailable','confidence'=>'unavailable','reason'=>'Holiday data unavailable.');}
        $airport=$report['airports'][0]??null;if($airport){$arrival=8;if(($airport['distanceKm']??0)>80)$arrival-=2;if(!empty($p['late_arrival']))$arrival-=2;if(!empty($p['mobility']))$arrival-=1;$arrival=max(0,$arrival);$dims['arrival']=array('score'=>$arrival,'max'=>10,'status'=>'scored','confidence'=>'medium','reason'=>!empty($p['late_arrival'])?'Reference airport found; late-arrival transfer still needs verification':'Reference airport and straight-line distance checked; actual ground transport is not scored');$earned+=$arrival;$availableMax+=10;}else{$dims['arrival']=array('score'=>null,'max'=>10,'status'=>'unavailable','confidence'=>'unavailable','reason'=>'Airport reference data unavailable.');}
        if(($report['country']['status']??'')==='available'||($report['nearby']['status']??'')==='available'){$practical=0;$reason=array();if(($report['country']['status']??'')==='available'){$practical+=7;$reason[]='country intelligence loaded';}if(($report['nearby']['status']??'')==='available'){$practical+=2;$reason[]='nearby essentials loaded';}else{$reason[]='nearby essentials unavailable';}$dims['practicality']=array('score'=>$practical,'max'=>10,'status'=>'scored','confidence'=>$practical>=9?'medium':'partial','reason'=>implode('; ',$reason));$earned+=$practical;$availableMax+=10;}else{$dims['practicality']=array('score'=>null,'max'=>10,'status'=>'unavailable','confidence'=>'unavailable','reason'=>'Practical destination sources unavailable.');}
        $pct=$availableMax?round($earned/$availableMax*100):null;$coverage=$availableMax?round($availableMax/$scorableMax*100):0;$label=$pct===null?'Not enough data':($pct>=85?'Strong live-data fit':($pct>=70?'Good with checks':($pct>=55?'Plan carefully':'High verification need')));
        return array('score'=>$pct,'coveragePercent'=>$coverage,'coverageLabel'=>'Scorable integrated coverage','entryScored'=>false,'label'=>$label,'dimensions'=>$dims,'notice'=>'The score uses only available integrated signals. Entry remains a separate official-verification item. Missing data does not mean safe, visa-free or suitable.');
    }
    private static function freshness($report){
        $rows=array();$add=function($name,$status,$observed=null,$retrieved=null,$source=null,$note=null)use(&$rows){$rows[]=array('name'=>$name,'status'=>$status,'observedAt'=>$observed,'retrievedAt'=>$retrieved?:self::now(),'source'=>$source,'note'=>$note);};
        $cur=$report['weather']['parts']['current']??array();$add('Current weather',!empty($cur['ok'])?'live':'unavailable',$cur['current']['observedAt']??null,$cur['meta']['generatedAt']??null,$cur['source']??null);
        $fc=$report['weather']['parts']['forecast']??array();$add('Five-day forecast',!empty($fc['ok'])?'forecast':'unavailable',null,$fc['meta']['generatedAt']??null,$fc['source']??null,'Daily rain is shown as peak 3-hour precipitation probability.');
        $aq=$report['weather']['parts']['airQuality']??array();$add('Air quality',!empty($aq['ok'])?'live':'unavailable',$aq['airQuality']['observedAt']??null,$aq['meta']['generatedAt']??null,$aq['source']??null,$aq['airQuality']['scaleNotice']??null);
        $usStatus=$report['advisories']['us']['status']??'unavailable';$ukStatus=$report['advisories']['uk']['status']??'unavailable';$adStatus=($usStatus==='available'&&$ukStatus==='available')?'official':(($usStatus==='available'||$ukStatus==='available')?'partial':'unavailable');
        $add('Official advisories',$adStatus,null,$report['generatedAt']??null,'U.S. Department of State + UK FCDO',$adStatus==='partial'?'One official advisory source was unavailable.':null);
        $add('Health notices',($report['healthNotices']['status']??'')==='available'?'official':'unavailable',null,$report['healthNotices']['generatedAt']??null,'CDC Travelers’ Health',$report['healthNotices']['matchingPolicy']??null);
        $hazards=$report['hazards']??array();$hazardStatus=$hazards['coverageStatus']??'unavailable';$add('Hazards',$hazardStatus==='complete'?'live':$hazardStatus,null,$hazards['generatedAt']??null,'USGS + GDACS + NASA + official warning feeds',$hazardStatus==='partial'?'Some hazard sources were unavailable or not applicable.':null);
        $add('Country intelligence',($report['country']['status']??'')==='available'?'reference':'unavailable',null,$report['generatedAt']??null,'Voyasee Country Intelligence');return $rows;
    }
    public static function report($p){
        $lat=(float)$p['lat'];$lon=(float)$p['lon'];$ctx=self::country_context($p['country']);$weather=self::weather($lat,$lon);$country=self::country_data($ctx['code']);$holidays=$country['country']['holidays']['holidays']??($country['country']['holidays']??array());if(isset($holidays['holidays']))$holidays=$holidays['holidays'];if(!is_array($holidays))$holidays=array();$today=gmdate('Y-m-d');
        $tripLength=max(1,min(30,(int)($p['trip_length']??7)));
        // Use trip length (min 7d) as the holiday lookahead window so only
        // holidays overlapping the actual trip affect the timing score.
        $holidayWindow=max(7,$tripLength)*DAY_IN_SECONDS;
        $holidaySoon=false;foreach($holidays as $h){$date=$h['date']??'';if($date>=$today&&strtotime($date)-time()<=$holidayWindow){$holidaySoon=true;break;}}
        $r=array('ok'=>true,'version'=>VTI_VERSION,'generatedAt'=>self::now(),'destination'=>array('place'=>$p['place']??$ctx['name'],'countryCode'=>$ctx['code'],'countryName'=>$ctx['name'],'lat'=>$lat,'lon'=>$lon),'profile'=>array('passport'=>$p['passport']??'OTHER','tripStyle'=>$p['trip_style']??'first','tripLength'=>$tripLength,'arrivalDate'=>$p['arrival_date']??null,'arrivalTime'=>$p['arrival_time']??null,'travellerType'=>$p['traveller_type']??'solo','luggage'=>$p['luggage']??'carry-on','aqSensitive'=>!empty($p['aq_sensitive']),'heatSensitive'=>!empty($p['heat_sensitive']),'lateArrival'=>!empty($p['late_arrival']),'mobility'=>!empty($p['mobility']),'tripLengthDays'=>$tripLength),
            'timezone'=>self::timezone($lat,$lon),'weather'=>$weather,'country'=>$country,'holidays'=>$holidays,'holidaySoon'=>$holidaySoon,'advisories'=>self::advisories($ctx['code']),'healthNotices'=>self::health_notices($ctx['code']),'hazards'=>self::hazards($lat,$lon,$ctx['code']),'airports'=>self::nearest_airports($lat,$lon,5),'nearby'=>!empty($p['include_nearby'])?self::nearby($lat,$lon,6000):array('status'=>'skipped','places'=>array()),'officialLinks'=>self::official_links($ctx,$p['passport']??'OTHER'));
        $providerPart=$weather['parts']['alerts']??array();$providerAlerts=$providerPart['alerts']??array();$providerAvailable=!empty($providerPart['ok']);
        if($providerAvailable){
            $providerSource=$providerPart['source']??'Voyasee Weather Bridge';
            $r['hazards']['providerWeatherAlerts']=array('status'=>'available','alerts'=>$providerAlerts,'source'=>$providerSource);
            $existing=$r['hazards']['officialWeatherAlerts']['alerts']??array();
            $r['hazards']['officialWeatherAlerts']['alerts']=array_values(array_merge($existing,$providerAlerts));
            $sources=$r['hazards']['officialWeatherAlerts']['sources']??array();$sources[]=$providerSource;
            $r['hazards']['officialWeatherAlerts']['sources']=array_values(array_unique(array_filter($sources)));
            $r['hazards']['officialWeatherAlerts']['status']='available';
            if($providerAlerts&&($r['hazards']['overallSeverity']??'none')==='none')$r['hazards']['overallSeverity']='medium';
            if(($r['hazards']['coverageStatus']??'unavailable')==='unavailable')$r['hazards']['coverageStatus']='partial';
        }else{$r['hazards']['providerWeatherAlerts']=array('status'=>'unavailable','alerts'=>array());if(($r['hazards']['coverageStatus']??'unavailable')==='complete')$r['hazards']['coverageStatus']='partial';}
        $r['activityMatrix']=self::activity_matrix($weather,$holidays,!empty($p['aq_sensitive']));$r['airQualityTrend']=self::aq_trend($weather);$r['readiness']=self::readiness($r,$p);$r['freshness']=self::freshness($r);
        $r['arrivalReality']=array('nearestAirport'=>$r['airports'][0]??null,'lateArrival'=>!empty($p['late_arrival']),'summary'=>(!empty($p['late_arrival'])?'Pre-book a verified transfer or choose a central first-night stay.':'Check airport-to-centre transport before payment.'),'notice'=>'Airport distance is straight-line distance; actual transfer time depends on route and traffic.');
        $r['dataGaps']=array_values(array_filter(array(
            ($r['weather']['status']??'')!=='available'?'Weather Bridge unavailable':null,
            ($r['country']['status']??'')!=='available'?'Country Intelligence unavailable':null,
            self::enabled('state_department')&&($r['advisories']['us']['status']??'')!=='available'?'U.S. advisory not parsed':null,
            self::enabled('govuk')&&($r['advisories']['uk']['status']??'')!=='available'?'UK advice unavailable':null,
            (($r['hazards']['coverageStatus']??'')==='partial')?'Hazard coverage partial':null,
            !empty($p['include_nearby'])&&self::enabled('overpass')&&($r['nearby']['status']??'')!=='available'?'Nearby essentials unavailable':null,
        )));
        return $r;
    }
}
