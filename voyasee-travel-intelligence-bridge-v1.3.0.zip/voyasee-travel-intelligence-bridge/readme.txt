=== Voyasee Travel Intelligence Bridge ===
Contributors: voyasee
Tags: travel, weather, advisories, hazards, airports, timezone, wordpress-rest-api
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A server-side destination-intelligence layer for the Voyasee Smart Travel Hub.

== Description ==

Voyasee Travel Intelligence Bridge is a master WordPress REST plugin designed to work beside:

* Voyasee Weather Bridge 1.3.0 or newer
* Voyasee Country Intelligence 2.0.0 or newer

It does not replace those plugins. It combines their normalized data with separate travel-intelligence modules and returns one structured report for the Smart Travel Hub.

Main capabilities:

* Coordinate-based IANA timezone lookup from a bundled offline grid
* Nearest-airport lookup from a bundled offline airport reference dataset
* U.S. Department of State advisory retrieval without inventing a level
* GOV.UK foreign-travel-advice retrieval
* Conservative CDC travel-health notice matching using exact country-title or explicitly global notices
* Thresholded USGS earthquake awareness
* GDACS disaster awareness
* NASA EONET natural-event awareness
* Optional NASA FIRMS satellite fire detections with a free MAP_KEY
* U.S. National Weather Service alerts for U.S. coordinates
* Optional MeteoAlarm warning integration for supported European countries
* OpenStreetMap/Overpass nearby essentials with server-side caching
* Five-day activity matrix using forecast, US AQI, UV and public holidays
* Explainable readiness dimensions that never guess exact visa or entry eligibility
* Source freshness, availability and data-gap reporting

The plugin labels live, official, reference, estimated and unavailable data separately. It is a planning layer, not a government, embassy, medical, airline, insurance or legal authority.

== Installation ==

1. Keep Voyasee Weather Bridge and Voyasee Country Intelligence active.
2. Upload and activate this plugin.
3. Open Settings > Voyasee Intelligence.
4. Keep the default public modules enabled unless a source should be disabled.
5. Optionally add a NASA FIRMS MAP_KEY and MeteoAlarm token.
6. Test `/wp-json/voyasee-intelligence/v1/health`.
7. Add the V21 Smart Travel Hub HTML to a WordPress Custom HTML block.

== REST API ==

Base namespace:

`/wp-json/voyasee-intelligence/v1`

Public routes:

* `/health`
* `/report`
* `/timezone`
* `/airports`
* `/nearby`
* `/hazards`
* `/advisories`
* `/health-notices`

Administrator-only route:

* `/diagnostics`

Example report request:

`/wp-json/voyasee-intelligence/v1/report?lat=13.7563&lon=100.5018&country=TH&place=Bangkok&passport=IN&trip_length=7&include_nearby=1`

== Privacy and operational notes ==

* Requests are rate-limited per route and visitor IP.
* Destination coordinates are rounded in cache keys where practical.
* No user account is required by the frontend.
* The plugin does not produce an exact visa decision.
* Public upstream sources may be temporarily unavailable, incomplete or not applicable to a location.
* Optional modules degrade honestly when no key or token is configured.
* OpenStreetMap/Overpass results are cached and should not be treated as guaranteed opening-hours or emergency-service confirmation.

== Bundled data ==

The plugin bundles:

* Airport reference data derived from OurAirports through the airportsdata package.
* A 0.5-degree timezone grid created with timezonefinder and timezone-boundary-builder data.

See `SOURCES-AND-LICENSING.md` for attribution and licence information.

== Changelog ==

= 1.1.0 =
* Added unified destination report.
* Added coordinate timezone lookup.
* Added nearest airports.
* Added official advisory and health-notice modules.
* Added hazard and nearby-essential modules.
* Added five-day activity matrix, AQI trend, arrival reality, freshness and data-gap reporting.
* Added dependency notices, settings validation and administrator diagnostics.


= 1.2.0 =
Accuracy and consistency repair release for canonical official advisories, conservative CDC matching, hazard coverage, nearby-essential fallback, daily AQI/forecast activity planning, evidence-aware readiness and source freshness.
