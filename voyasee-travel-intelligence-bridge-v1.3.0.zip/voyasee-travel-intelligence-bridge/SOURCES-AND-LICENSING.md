# Voyasee Travel Intelligence Bridge — Sources and Licensing

This file records the principal source and attribution requirements used by the plugin. It is not legal advice. Source terms can change, so they should be reviewed before major redistribution or architectural changes.

## Voyasee dependencies

- **Voyasee Weather Bridge** — local WordPress plugin. The master plugin calls its PHP service class server-side.
- **Voyasee Country Intelligence** — local WordPress plugin. The master plugin calls its PHP data class server-side.

## Official and public online sources

- **U.S. Department of State** — official travel-advisory pages. Results are shown with the issuing government and audience; no level is invented when parsing fails.
- **GOV.UK / UK FCDO** — foreign-travel-advice content. Reuse is subject to applicable GOV.UK/Open Government Licence terms and attribution.
- **CDC Travelers’ Health** — travel-health notice RSS metadata and links. The plugin presents summaries and links back to the official source.
- **U.S. National Weather Service** — official U.S. weather alerts for supported coordinates. Attribution is retained in response data.
- **MeteoAlarm / EUMETNET members** — optional warning data for supported European countries. Configure only with a valid re-user token and follow the provider’s current attribution and reuse terms.
- **USGS Earthquake Hazards Program** — earthquake event metadata and links.
- **GDACS** — disaster-event metadata and links.
- **NASA EONET** — natural-event metadata and links.
- **NASA FIRMS** — optional satellite fire/thermal detections. A configured MAP_KEY is required. Satellite detections are not labelled as confirmed dangerous wildfires.
- **OpenStreetMap contributors / Overpass API** — nearby map features. Data is under the Open Database Licence. The frontend and API responses retain OpenStreetMap attribution. Public Overpass infrastructure is cached and is not treated as a guaranteed service-level provider.

## Bundled airport dataset

`data/airports.min.json`

- Generated from the `airportsdata` reference package, which is derived from OurAirports data.
- Dataset metadata is stored inside the JSON file.
- Retain the upstream attribution and review the current upstream licence before redistributing the data separately from the plugin.

## Bundled timezone dataset

`data/timezone-grid.bin` and `data/timezone-grid.json`

- Generated using `timezonefinder` with timezone-boundary-builder-derived boundary data.
- The metadata file records a 0.5-degree grid resolution and the source names.
- `timezonefinder` software is MIT-licensed; timezone boundary data carries its own attribution/reuse obligations, including ODbL-related requirements where applicable.
- The output is an approximate coordinate lookup. Locations close to a time-zone border may need verification.

## General presentation rules

1. Never label unavailable information as “safe,” “clear,” or “visa-free.”
2. Preserve the issuing authority’s own advisory level and wording.
3. Label forecast, estimate, curated guidance and official data separately.
4. Keep source links and attribution visible where the frontend displays source-derived information.
5. Exact visa, health, medicine, airline, legal and entry decisions require official verification.
