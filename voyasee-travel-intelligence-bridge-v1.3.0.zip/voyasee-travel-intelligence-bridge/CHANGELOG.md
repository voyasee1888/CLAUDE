# Changelog

## 1.3.0
- Added IPapi.com key option in WP Admin settings; key is injected into `window.VoyaseeIntelligenceConfig.ipapiKey` for the Travel Hub frontend.
- Fixed `country_context()` being called 3× per `/report` request — now cached in a static array.
- Fixed `nearby()` Overpass results cached for 14 days — reduced to 24 hours.
- Fixed `state_department()` fallback to the generic list page which could return a wrong country's advisory level — removed list-page URL from parse loop.
- Added error_log entry when State Dept advisory cannot be parsed, for easier server-side diagnostics.
- Fixed airport loop running Haversine on all 8,000+ airports — added lat/lon bounding-box pre-filter.
- Fixed holiday timing window hardcoded at 21 days — now uses `trip_length` parameter (min 7 days).
- Added object-cache guard in `rate_limit()` — skips DB-backed transient rate limiting when no external object cache (Redis/Memcached) is active.

## 1.2.0
- Repaired U.S. State Department canonical advisory parsing and shortened failure caching.
- Replaced misleading GOV.UK change-description summaries with actual alert-status guidance.
- Rebuilt CDC matching to accept only exact country names in titles or explicitly global notices.
- Added multi-endpoint Nearby Essentials fallback plus direct OpenStreetMap search links.
- Added hazard coverage state so missing feeds cannot appear as a confirmed all-clear.
- Added destination-local daily AQI forecast grouping and clarified peak 3-hour rain probability.
- Rebalanced readiness scoring and separated scorable coverage from entry verification.
- Improved freshness notes and partial-source reporting.
- Reduced health-score impact for explicitly global CDC notices compared with country-title matches.

## 1.1.0
- Initial V21 master intelligence release.
